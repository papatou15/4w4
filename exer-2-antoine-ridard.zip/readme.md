# Exrcice #1 - 4W4 - Conception d'interface et développement Web
### Auteur : Eddy Martin
### Date de remise : 11 février 2022

```
Cet exercice nous a permis d'introduire la structure d'un thème Wordpress. Voici la structure utilisée:
-Pour le style css nous avons utilisé Sass
-Les fonctions du thème se trouvent dans «functions.php»
-Les modèle principal est : «index.php»

Pour modifier readme.md
https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax